<template>
    <div class="jogo">
        
        <ForcaVue
            :erros="erros"
        />
        <PalavraVue
            :palavra="palavra"
            :dica="dica"
            :verificarLetra="verificarLetra"
            :etapa="etapa"
        />

        <TecladoVue 
            v-if="etapa === 'jogo'"
            :letras="letras"
            :verificarLetra="verificarLetra"
            :jogar="jogar"
        />

        <FinalVue
            v-if="etapa != 'jogo'"
            :etapa="etapa"
            :texto="etapa === 'ganhador' ? 'Parabéns' : 'Tadinho'"
            :jogarNovamente="jogarNovamente"
        />


    </div>
</template>

<script>

import ForcaVue from './Forca.vue';
import PalavraVue from './Palavra.vue';
import TecladoVue from './Teclado.vue';
import FinalVue from './Final.vue';

export default {
    name: 'Jogo',
    props: {
        erros: Number,
        palavra: String,
        dica: String,   
        verificarLetra: Function,
        etapa: String,
        letras: Array,
        jogar: Function,
        jogarNovamente: Function   
    },
    data(){
        return {

        }
    },
    methods: {
       
    },
    components: {
    ForcaVue,
    PalavraVue,
    TecladoVue,
    FinalVue,
}
}

</script>

<style>

.jogo{
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}
   
</style>